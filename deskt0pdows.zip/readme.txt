Malware Name: deskt0pdows
Works Best In: Windows XP
Made In: C++
Malware Type: Trojan
Damage rate: Destructive
Created By: Minhgotuknight19

Credits To GetMBR For Hue functions

The Safety Version is Safe on Real Machine, But The Destructive Version Will Disabled Task manger And Cmd, Corrupt Your MBR, Run Only On A VM